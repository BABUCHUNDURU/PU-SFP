// Schedule disbursement 6 days after the period started.
return period.startDate.plusDays(6)