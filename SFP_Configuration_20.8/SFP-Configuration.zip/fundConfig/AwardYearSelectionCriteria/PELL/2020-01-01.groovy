/* Pell Award Year Selection Criteria - combined Term and Non-Term*/

return crossoverHelper.useCurrentAlternative(); 