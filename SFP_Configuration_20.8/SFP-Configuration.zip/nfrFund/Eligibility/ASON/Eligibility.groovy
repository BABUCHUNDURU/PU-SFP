import com.oracle.sfp.scripting.api.NfrEligibilityField

return [new NfrEligibilityField("Is eligible", true)]